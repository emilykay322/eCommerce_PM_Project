import { MessageCircle, Search, ShoppingBag, Heart, User, Home, Package, Star, ArrowLeft, Truck, RotateCcw, CreditCard, UserCircle, Send, Bot, X, Phone, Paperclip } from "lucide-react";
import { ImageWithFallback } from "./components/figma/ImageWithFallback";
import { useState } from "react";

export default function App() {
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [showTrackOrder, setShowTrackOrder] = useState(false);
  const [showTrackingDetails, setShowTrackingDetails] = useState(false);
  const [showReturnFlow, setShowReturnFlow] = useState(false);
  const [showReturnReason, setShowReturnReason] = useState(false);
  const [showReturnSummary, setShowReturnSummary] = useState(false);
  const [showReturnConfirmed, setShowReturnConfirmed] = useState(false);
  const [showEndConversation, setShowEndConversation] = useState(false);
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);
  const [selectedSatisfaction, setSelectedSatisfaction] = useState<number | null>(null);
  const [selectedResolved, setSelectedResolved] = useState<string | null>(null);
  const [inputMessage, setInputMessage] = useState("");
  const [customMessages, setCustomMessages] = useState<string[]>([]);
  const [showBillingResponse, setShowBillingResponse] = useState(false);
  const [showPersonHandoff, setShowPersonHandoff] = useState(false);
  const [showHelpWithOrder, setShowHelpWithOrder] = useState(false);
  const [showSomethingElse, setShowSomethingElse] = useState(false);
  const [showMissingAccessories, setShowMissingAccessories] = useState(false);
  const [showAccountTransfer, setShowAccountTransfer] = useState(false);
  const [showEscalation, setShowEscalation] = useState(false);
  const [showTalkToRealPerson, setShowTalkToRealPerson] = useState(false);

  // Get current time for chat timestamp
  const currentTime = new Date().toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  });
  const categories = [
    { name: "Electronics", icon: "📱" },
    { name: "Fashion", icon: "👗" },
    { name: "Home", icon: "🏠" },
    { name: "Beauty", icon: "💄" },
  ];

  const featuredProducts = [
    { id: 1, name: "Wireless Headphones", price: "$129.99", rating: 4.5, image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400" },
    { id: 2, name: "Smart Watch", price: "$299.99", rating: 4.8, image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400" },
    { id: 3, name: "Camera Lens", price: "$449.99", rating: 4.6, image: "https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?w=400" },
    { id: 4, name: "Sneakers", price: "$89.99", rating: 4.7, image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400" },
  ];

  const chatOptions = [
    { label: "Track an order", action: () => setShowTrackOrder(true) },
    { label: "Return an item", action: () => setShowReturnFlow(true) },
    { label: "Billing question", action: null },
    { label: "Something else", action: null },
  ];

  const trackOrderOptions = [
    { label: "Track Wireless Headphones with FedEx", action: () => setShowTrackingDetails(true) },
    { label: "Return an item" },
    { label: "Something else" },
    { label: "End conversation", action: () => setShowEndConversation(true) },
  ];

  const trackingDetailsOptions = [
    { label: "Help with something else" },
    { label: "End conversation", action: () => setShowEndConversation(true) },
  ];

  const returnOptionsTop = [
    { label: "Yes, return the phone case", action: () => setShowReturnReason(true) },
  ];

  const returnOptionsBottom = [
    { label: "Something else" },
    { label: "End conversation", action: () => setShowEndConversation(true) },
  ];

  const returnReasonOptions = [
    [{ label: "Doesn't fit" }, { label: "Changed my mind" }],
    [{ label: "Damaged or defective", action: () => setShowReturnSummary(true) }],
    [{ label: "Wrong item received" }],
    [{ label: "Not as described" }, { label: "Missing parts" }],
    [{ label: "Other" }, { label: "End conversation", action: () => setShowEndConversation(true) }],
  ];

  const confirmOptions = [
    { label: "Confirm return", action: () => setShowReturnConfirmed(true) },
    { label: "Cancel", action: () => setShowEndConversation(true) },
  ];

  const finalOptions = [
    { label: "Help with something else" },
    { label: "End conversation", action: () => setShowEndConversation(true) },
  ];

  const satisfactionEmojis = ["😞", "🙁", "😐", "🙂", "😊"];

  return (
    <div className="w-full h-screen bg-page-background relative flex flex-col">
      {/* Chat Interface */}
      {isChatOpen && (
        <div className="absolute inset-0 bg-page-background z-[100] flex flex-col">
          {/* Chat Header */}
          <header className="bg-background border-b" style={{ borderColor: 'var(--border)' }}>
            <div className="flex items-center justify-between px-4 py-3">
              <div className="flex items-center gap-3">
                <div className="bg-primary rounded-full w-12 h-12 flex items-center justify-center text-white" style={{ fontSize: '18px', fontWeight: 'var(--font-weight-semibold)' }}>
                  A
                </div>
                <div>
                  <h2 className="text-foreground" style={{ fontSize: 'var(--text-header)', fontWeight: 'var(--font-weight-semibold)' }}>
                    Aria — ShopFlow Support
                  </h2>
                  <div className="flex items-center gap-1">
                    <div className="w-2 h-2 rounded-full bg-online-green"></div>
                    <span className="text-online-green" style={{ fontSize: 'var(--text-small)' }}>Online now</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button className="text-text-medium hover:text-foreground p-1">
                  <Phone className="w-5 h-5" />
                </button>
                <button
                  onClick={() => {
                    // If user is in a conversation flow, show survey first
                    if (showTrackOrder || showReturnFlow) {
                      setShowEndConversation(true);
                    } else {
                      // Otherwise just close the chat
                      setIsChatOpen(false);
                    }
                  }}
                  className="text-text-medium hover:text-foreground p-1"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* AI Banner - Full Width */}
            <div className="bg-ai-banner-bg border-b px-4 py-2 flex items-center justify-between" style={{ borderColor: 'var(--ai-banner-border)', backgroundColor: 'var(--ai-banner-bg)' }}>
              <div className="flex items-center gap-2">
                <Bot className="w-4 h-4 text-text-medium" />
                <span className="text-text-secondary" style={{ fontSize: 'var(--text-small)' }}>
                  You're chatting with an AI assistant
                </span>
              </div>
              <button
                onClick={() => setShowTalkToRealPerson(true)}
                className="text-primary hover:underline"
                style={{ fontSize: 'var(--text-small)', fontWeight: 'var(--font-weight-medium)' }}
              >
                Talk to a person
              </button>
            </div>
          </header>

          {/* Chat Content */}
          <div className="flex-1 overflow-y-auto px-4 py-6 bg-background">
            {/* Chat timestamp */}
            <div className="text-center mb-6">
              <span className="text-text-placeholder" style={{ fontSize: 'var(--text-small)' }}>
                Today 10:27 PM
              </span>
            </div>

            {/* Aria's Initial Message and Options */}
            <div className="mb-6">
              <div className="ml-14 flex flex-col gap-3">
                {/* Message bubble */}
                <div className="bg-surface-light px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopLeftRadius: 'var(--radius-bubble-tail)', maxWidth: '260px' }}>
                  <p className="text-foreground" style={{ fontSize: 'var(--text-body)' }}>
                    Hi Maya 👋 I'm Aria, your ShopFlow support assistant. What can I help you with today?
                  </p>
                </div>

                {/* Quick reply options - 2x2 grid */}
                {!showReturnFlow && !showTrackOrder && customMessages.length === 0 && (
                  <div className="grid grid-cols-2 gap-2" style={{ maxWidth: '260px' }}>
                    {chatOptions.map((option, index) => (
                      <button
                        key={index}
                        onClick={option.action}
                        className="bg-background border text-primary hover:bg-primary-lighter transition-all px-3 py-2 text-center"
                        style={{
                          borderColor: 'var(--border)',
                          borderRadius: 'var(--radius-chip)',
                          fontSize: 'var(--text-button)',
                          fontWeight: 'var(--font-weight-medium)',
                          borderWidth: '1px'
                        }}
                      >
                        {option.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Avatar and Timestamp - stays with initial message */}
              {!showReturnFlow && !showTrackOrder && (
                <div className="flex gap-3 items-center mt-2">
                  <div className="bg-primary rounded-full w-10 h-10 flex-shrink-0 flex items-center justify-center text-white" style={{ fontSize: '14px', fontWeight: 'var(--font-weight-semibold)' }}>
                    A
                  </div>
                  <span className="text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>10:27 PM</span>
                </div>
              )}
            </div>

            {/* Custom User Messages - show only non-flow messages */}
            {customMessages.filter(msg =>
              !msg.toLowerCase().includes("help with order") &&
              !msg.toLowerCase().includes("talk to a person now") &&
              !msg.toLowerCase().includes("something else") &&
              !msg.toLowerCase().includes("missing accessories") &&
              !msg.toLowerCase().includes("change the name on my account") &&
              !(msg.toLowerCase().includes("third time") && msg.toLowerCase().includes("canceling"))
            ).map((message, index) => {
              let timestamp = "02:33 PM";

              return (
                <div key={index} className="mb-4">
                  <div className="flex justify-end">
                    <div className="flex flex-col items-end">
                      <div className="bg-primary text-white px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopRightRadius: 'var(--radius-bubble-tail)', maxWidth: '260px' }}>
                        <p style={{ fontSize: 'var(--text-body)' }}>{message}</p>
                      </div>
                      <span className="mt-1 mr-2 text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>
                        {timestamp}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}

            {/* Billing Response */}
            {showBillingResponse && (
              <div className="mb-2">
                <div className="ml-14 flex flex-col gap-3">
                  {/* Message bubble with billing response */}
                  <div className="bg-surface-light px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopLeftRadius: 'var(--radius-bubble-tail)', maxWidth: '280px' }}>
                    <p className="text-foreground mb-3" style={{ fontSize: 'var(--text-body)' }}>
                      I can see what happened. On April 22nd, you were charged twice for $27.05 — once for your phone case order, and a second charge with no matching order. This has already been flagged as a duplicate and is under review by our billing team.
                    </p>
                    <p className="text-foreground" style={{ fontSize: 'var(--text-body)' }}>
                      You should see a refund for the duplicate $27.05 charge processed back to your Visa ending in 4242 within 3–5 business days. If you don't see it by then, I can connect you with someone who can expedite it.
                    </p>
                  </div>

                  {/* Billing response options */}
                  {!showPersonHandoff && (
                    <div className="flex flex-col gap-2" style={{ maxWidth: '260px' }}>
                      {/* First two buttons - full width */}
                      <button
                        className="bg-background border text-primary hover:bg-primary-lighter transition-all px-3 py-2 text-center"
                        style={{
                          borderColor: 'var(--border)',
                          borderRadius: 'var(--radius-chip)',
                          fontSize: 'var(--text-button)',
                          fontWeight: 'var(--font-weight-medium)',
                          borderWidth: '1px'
                        }}
                      >
                        Check on this next week
                      </button>
                      <button
                        onClick={() => setShowPersonHandoff(true)}
                        className="bg-background border text-primary hover:bg-primary-lighter transition-all px-3 py-2 text-center"
                        style={{
                          borderColor: 'var(--border)',
                          borderRadius: 'var(--radius-chip)',
                          fontSize: 'var(--text-button)',
                          fontWeight: 'var(--font-weight-medium)',
                          borderWidth: '1px'
                        }}
                      >
                        Talk to a person now
                      </button>

                      {/* Bottom row - 2 buttons */}
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          className="bg-background border text-primary hover:bg-primary-lighter transition-all px-3 py-2 text-center"
                          style={{
                            borderColor: 'var(--border)',
                            borderRadius: 'var(--radius-chip)',
                            fontSize: 'var(--text-button)',
                            fontWeight: 'var(--font-weight-medium)',
                            borderWidth: '1px'
                          }}
                        >
                          Something else
                        </button>
                        <button
                          onClick={() => setShowEndConversation(true)}
                          className="bg-background border text-primary hover:bg-primary-lighter transition-all px-3 py-2 text-center"
                          style={{
                            borderColor: 'var(--border)',
                            borderRadius: 'var(--radius-chip)',
                            fontSize: 'var(--text-button)',
                            fontWeight: 'var(--font-weight-medium)',
                            borderWidth: '1px'
                          }}
                        >
                          End conversation
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Avatar and Timestamp at bottom */}
                {!showPersonHandoff && (
                  <div className="flex gap-3 items-center mt-2">
                    <div className="bg-primary rounded-full w-10 h-10 flex-shrink-0 flex items-center justify-center text-white" style={{ fontSize: '14px', fontWeight: 'var(--font-weight-semibold)' }}>
                      A
                    </div>
                    <span className="text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>02:33 PM</span>
                  </div>
                )}
              </div>
            )}

            {/* Help with Order Response */}
            {showHelpWithOrder && (
              <>
                {/* User Message - Help with order */}
                <div className="flex justify-end mb-4">
                  <div className="flex flex-col items-end">
                    <div className="bg-primary text-white px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopRightRadius: 'var(--radius-bubble-tail)', maxWidth: '200px' }}>
                      <p style={{ fontSize: 'var(--text-body)' }}>Help with order</p>
                    </div>
                    <span className="mt-1 mr-2 text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>02:40 PM</span>
                  </div>
                </div>

                <div className="mb-2">
                <div className="ml-14 flex flex-col gap-3">
                  {/* Message bubble with order list */}
                  <div className="bg-surface-light px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopLeftRadius: 'var(--radius-bubble-tail)', maxWidth: '280px' }}>
                    <p className="text-foreground mb-3" style={{ fontSize: 'var(--text-body)' }}>
                      You have 3 orders:
                    </p>

                    <div className="mb-3">
                      <p className="text-foreground" style={{ fontSize: 'var(--text-body)' }}>
                        1. <span style={{ fontWeight: 'var(--font-weight-semibold)' }}>Wireless Headphones</span> (ORD-4471) — Out for delivery, arriving by May 2
                      </p>
                    </div>

                    <div className="mb-3">
                      <p className="text-foreground" style={{ fontSize: 'var(--text-body)' }}>
                        2. <span style={{ fontWeight: 'var(--font-weight-semibold)' }}>Phone Case – Midnight Black</span> (ORD-4392) — Delivered April 25
                      </p>
                    </div>

                    <div className="mb-3">
                      <p className="text-foreground" style={{ fontSize: 'var(--text-body)' }}>
                        3. <span style={{ fontWeight: 'var(--font-weight-semibold)' }}>Mechanical Keyboard – Compact</span> (ORD-4180) — Returned March 20
                      </p>
                    </div>

                    <p className="text-foreground" style={{ fontSize: 'var(--text-body)' }}>
                      What would you like help with?
                    </p>
                  </div>

                  {/* Help with order options */}
                  {!showSomethingElse && (
                    <div className="flex flex-col gap-2" style={{ maxWidth: '260px' }}>
                      {/* First button - full width */}
                      <button
                        className="bg-background border text-primary hover:bg-primary-lighter transition-all px-3 py-2 text-center"
                        style={{
                          borderColor: 'var(--border)',
                          borderRadius: 'var(--radius-chip)',
                          fontSize: 'var(--text-button)',
                          fontWeight: 'var(--font-weight-medium)',
                          borderWidth: '1px'
                        }}
                      >
                        Track Wireless Headphones
                      </button>

                      {/* Second row - 2 buttons */}
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          className="bg-background border text-primary hover:bg-primary-lighter transition-all px-3 py-2 text-center"
                          style={{
                            borderColor: 'var(--border)',
                            borderRadius: 'var(--radius-chip)',
                            fontSize: 'var(--text-button)',
                            fontWeight: 'var(--font-weight-medium)',
                            borderWidth: '1px'
                          }}
                        >
                          Return Phone Case
                        </button>
                        <button
                          onClick={() => setShowSomethingElse(true)}
                          className="bg-background border text-primary hover:bg-primary-lighter transition-all px-3 py-2 text-center"
                          style={{
                            borderColor: 'var(--border)',
                            borderRadius: 'var(--radius-chip)',
                            fontSize: 'var(--text-button)',
                            fontWeight: 'var(--font-weight-medium)',
                            borderWidth: '1px'
                          }}
                        >
                          Something else
                        </button>
                      </div>

                      {/* Third button - full width */}
                      <button
                        onClick={() => setShowEndConversation(true)}
                        className="bg-background border text-primary hover:bg-primary-lighter transition-all px-3 py-2 text-center"
                        style={{
                          borderColor: 'var(--border)',
                          borderRadius: 'var(--radius-chip)',
                          fontSize: 'var(--text-button)',
                          fontWeight: 'var(--font-weight-medium)',
                          borderWidth: '1px'
                        }}
                      >
                        End conversation
                      </button>
                    </div>
                  )}
                </div>

                {/* Avatar and Timestamp at bottom */}
                <div className="flex gap-3 items-center mt-2">
                  <div className="bg-primary rounded-full w-10 h-10 flex-shrink-0 flex items-center justify-center text-white" style={{ fontSize: '14px', fontWeight: 'var(--font-weight-semibold)' }}>
                    A
                  </div>
                  <span className="text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>02:50 PM</span>
                </div>
              </div>
              </>
            )}

            {/* Something Else Flow */}
            {showSomethingElse && (
              <>
                {/* User Message - Something else */}
                <div className="flex justify-end mb-4">
                  <div className="flex flex-col items-end">
                    <div className="bg-primary text-white px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopRightRadius: 'var(--radius-bubble-tail)', maxWidth: '200px' }}>
                      <p style={{ fontSize: 'var(--text-body)' }}>Something else</p>
                    </div>
                    <span className="mt-1 mr-2 text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>02:51 PM</span>
                  </div>
                </div>

                {/* AI Response - Ask for more details */}
                <div className="mb-2">
                  <div className="ml-14 flex flex-col gap-3">
                    {/* Message bubble */}
                    <div className="bg-surface-light px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopLeftRadius: 'var(--radius-bubble-tail)', maxWidth: '280px' }}>
                      <p className="text-foreground" style={{ fontSize: 'var(--text-body)' }}>
                        Of course — can you tell me a little more about what's going on? I want to make sure I get you the right help.
                      </p>
                    </div>
                  </div>

                  {/* Avatar and Timestamp */}
                  <div className="flex gap-3 items-center mt-2">
                    <div className="bg-primary rounded-full w-10 h-10 flex-shrink-0 flex items-center justify-center text-white" style={{ fontSize: '14px', fontWeight: 'var(--font-weight-semibold)' }}>
                      A
                    </div>
                    <span className="text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>02:51 PM</span>
                  </div>
                </div>
              </>
            )}

            {/* Missing Accessories Flow */}
            {showMissingAccessories && (
              <>
                {/* User Message - Missing accessories */}
                <div className="flex justify-end mb-4">
                  <div className="flex flex-col items-end">
                    <div className="bg-primary text-white px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopRightRadius: 'var(--radius-bubble-tail)', maxWidth: '260px' }}>
                      <p style={{ fontSize: 'var(--text-body)' }}>I am missing accessories included in my last order</p>
                    </div>
                    <span className="mt-1 mr-2 text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>02:53 PM</span>
                  </div>
                </div>

                {/* AI Response - Connecting message */}
                <div className="mb-2">
                  <div className="ml-14 flex flex-col gap-3">
                    {/* Message bubble */}
                    <div className="bg-surface-light px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopLeftRadius: 'var(--radius-bubble-tail)', maxWidth: '280px' }}>
                      <p className="text-foreground" style={{ fontSize: 'var(--text-body)' }}>
                        I'm connecting you with Sarah Chen, who can check exactly what accessories should be included with your headphones and help resolve this. She'll be with you in about 3–5 minutes and will have all the details from our conversation.
                      </p>
                    </div>
                  </div>

                  {/* Avatar and Timestamp */}
                  <div className="flex gap-3 items-center mt-2">
                    <div className="bg-primary rounded-full w-10 h-10 flex-shrink-0 flex items-center justify-center text-white" style={{ fontSize: '14px', fontWeight: 'var(--font-weight-semibold)' }}>
                      A
                    </div>
                    <span className="text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>02:54 PM</span>
                  </div>
                </div>

                {/* Warning Banner */}
                <div className="bg-warning-bg border px-4 py-3 mb-4 mx-4" style={{ borderColor: 'var(--warning-border)', borderRadius: 'var(--radius-card-sm)' }}>
                  <div className="flex items-start gap-2 mb-2">
                    <span style={{ fontSize: '16px' }}>⚠️</span>
                    <p className="text-warning-text" style={{ fontSize: 'var(--text-body)', fontWeight: 'var(--font-weight-semibold)' }}>
                      Connecting you to <span style={{ fontWeight: 'var(--font-weight-semibold)' }}>Sarah Chen</span>
                    </p>
                  </div>
                  <p className="text-warning-text mb-1" style={{ fontSize: 'var(--text-body)', fontWeight: 'var(--font-weight-semibold)' }}>
                    Estimated wait: <span style={{ fontWeight: 'var(--font-weight-semibold)' }}>3–5 minutes</span>
                  </p>
                  <p className="text-warning-text" style={{ fontSize: 'var(--text-small)' }}>
                    Your conversation history has been shared with the agent.
                  </p>
                </div>

                {/* Agent Joined Message */}
                <div className="text-center mb-4">
                  <span className="text-text-placeholder" style={{ fontSize: 'var(--text-small)' }}>
                    Sarah Chen from Customer Support has joined the chat
                  </span>
                </div>

                {/* Sarah's Message */}
                <div className="mb-2">
                  <div className="ml-14 flex flex-col gap-3">
                    {/* Message bubble */}
                    <div className="bg-surface-light px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopLeftRadius: 'var(--radius-bubble-tail)', maxWidth: '280px' }}>
                      <p className="text-foreground" style={{ fontSize: 'var(--text-body)' }}>
                        Hi Maya. I'm Sarah Chen and I can see your conversation with Aria. I'm looking into this now and will be right with you.
                      </p>
                    </div>
                  </div>

                  {/* Avatar and Timestamp */}
                  <div className="flex gap-3 items-center mt-2">
                    <div className="rounded-full w-10 h-10 flex-shrink-0 flex items-center justify-center text-white" style={{ fontSize: '14px', fontWeight: 'var(--font-weight-semibold)', backgroundColor: '#06b6d4' }}>
                      S
                    </div>
                    <span className="text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>Sarah Chen · 02:54 PM</span>
                  </div>
                </div>
              </>
            )}

            {/* Account Transfer Flow */}
            {showAccountTransfer && (
              <>
                {/* User Message - Account transfer */}
                <div className="flex justify-end mb-4">
                  <div className="flex flex-col items-end">
                    <div className="bg-primary text-white px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopRightRadius: 'var(--radius-bubble-tail)', maxWidth: '280px' }}>
                      <p style={{ fontSize: 'var(--text-body)' }}>Can I change the name on my account to my wife's name? She's taking over the subscription</p>
                    </div>
                    <span className="mt-1 mr-2 text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>02:57 PM</span>
                  </div>
                </div>

                {/* AI Response - Connecting message */}
                <div className="mb-2">
                  <div className="ml-14 flex flex-col gap-3">
                    {/* Message bubble */}
                    <div className="bg-surface-light px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopLeftRadius: 'var(--radius-bubble-tail)', maxWidth: '280px' }}>
                      <p className="text-foreground" style={{ fontSize: 'var(--text-body)' }}>
                        You're being connected to Sarah Chen, who'll be with you in about 3–5 minutes. She'll have everything from our chat and can help you get the account transferred to your wife.
                      </p>
                    </div>
                  </div>

                  {/* Avatar and Timestamp */}
                  <div className="flex gap-3 items-center mt-2">
                    <div className="bg-primary rounded-full w-10 h-10 flex-shrink-0 flex items-center justify-center text-white" style={{ fontSize: '14px', fontWeight: 'var(--font-weight-semibold)' }}>
                      A
                    </div>
                    <span className="text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>02:57 PM</span>
                  </div>
                </div>

                {/* Warning Banner */}
                <div className="bg-warning-bg border px-4 py-3 mb-4 mx-4" style={{ borderColor: 'var(--warning-border)', borderRadius: 'var(--radius-card-sm)' }}>
                  <div className="flex items-start gap-2 mb-2">
                    <span style={{ fontSize: '16px' }}>⚠️</span>
                    <p className="text-warning-text" style={{ fontSize: 'var(--text-body)', fontWeight: 'var(--font-weight-semibold)' }}>
                      Connecting you to <span style={{ fontWeight: 'var(--font-weight-semibold)' }}>Sarah Chen</span>
                    </p>
                  </div>
                  <p className="text-warning-text mb-1" style={{ fontSize: 'var(--text-body)', fontWeight: 'var(--font-weight-semibold)' }}>
                    Estimated wait: <span style={{ fontWeight: 'var(--font-weight-semibold)' }}>3–5 minutes</span>
                  </p>
                  <p className="text-warning-text" style={{ fontSize: 'var(--text-small)' }}>
                    Your conversation history has been shared with the agent.
                  </p>
                </div>

                {/* Agent Joined Message */}
                <div className="text-center mb-4">
                  <span className="text-text-placeholder" style={{ fontSize: 'var(--text-small)' }}>
                    Sarah Chen from Customer Support has joined the chat
                  </span>
                </div>

                {/* Sarah's Message */}
                <div className="mb-2">
                  <div className="ml-14 flex flex-col gap-3">
                    {/* Message bubble */}
                    <div className="bg-surface-light px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopLeftRadius: 'var(--radius-bubble-tail)', maxWidth: '280px' }}>
                      <p className="text-foreground" style={{ fontSize: 'var(--text-body)' }}>
                        Hi Maya, I'm Sarah Chen and I can see your conversation with Aria. I'm looking into this now and will be right with you.
                      </p>
                    </div>
                  </div>

                  {/* Avatar and Timestamp */}
                  <div className="flex gap-3 items-center mt-2">
                    <div className="rounded-full w-10 h-10 flex-shrink-0 flex items-center justify-center text-white" style={{ fontSize: '14px', fontWeight: 'var(--font-weight-semibold)', backgroundColor: '#06b6d4' }}>
                      S
                    </div>
                    <span className="text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>Sarah Chen · 02:57 PM</span>
                  </div>
                </div>
              </>
            )}

            {/* Escalation Flow */}
            {showEscalation && (
              <>
                {/* User Message - Escalation */}
                <div className="flex justify-end mb-4">
                  <div className="flex flex-col items-end">
                    <div className="bg-primary text-white px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopRightRadius: 'var(--radius-bubble-tail)', maxWidth: '280px' }}>
                      <p style={{ fontSize: 'var(--text-body)' }}>this is the THIRD time I've contacted you about this broken product and nobody has done anything. I'm canceling my account</p>
                    </div>
                    <span className="mt-1 mr-2 text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>03:01 PM</span>
                  </div>
                </div>

                {/* AI Response - Connecting message */}
                <div className="mb-2">
                  <div className="ml-14 flex flex-col gap-3">
                    {/* Message bubble */}
                    <div className="bg-surface-light px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopLeftRadius: 'var(--radius-bubble-tail)', maxWidth: '280px' }}>
                      <p className="text-foreground" style={{ fontSize: 'var(--text-body)' }}>
                        You're being connected to Sarah Chen, who'll be with you in 3–5 minutes. She'll have full context of everything we've discussed and will make sure this gets taken care of.
                      </p>
                    </div>
                  </div>

                  {/* Avatar and Timestamp */}
                  <div className="flex gap-3 items-center mt-2">
                    <div className="bg-primary rounded-full w-10 h-10 flex-shrink-0 flex items-center justify-center text-white" style={{ fontSize: '14px', fontWeight: 'var(--font-weight-semibold)' }}>
                      A
                    </div>
                    <span className="text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>03:01 PM</span>
                  </div>
                </div>

                {/* Warning Banner */}
                <div className="bg-warning-bg border px-4 py-3 mb-4 mx-4" style={{ borderColor: 'var(--warning-border)', borderRadius: 'var(--radius-card-sm)' }}>
                  <div className="flex items-start gap-2 mb-2">
                    <span style={{ fontSize: '16px' }}>⚠️</span>
                    <p className="text-warning-text" style={{ fontSize: 'var(--text-body)', fontWeight: 'var(--font-weight-semibold)' }}>
                      Connecting you to <span style={{ fontWeight: 'var(--font-weight-semibold)' }}>Sarah Chen</span>
                    </p>
                  </div>
                  <p className="text-warning-text mb-1" style={{ fontSize: 'var(--text-body)', fontWeight: 'var(--font-weight-semibold)' }}>
                    Estimated wait: <span style={{ fontWeight: 'var(--font-weight-semibold)' }}>3–5 minutes</span>
                  </p>
                  <p className="text-warning-text" style={{ fontSize: 'var(--text-small)' }}>
                    Your conversation history has been shared with the agent.
                  </p>
                </div>

                {/* Agent Joined Message */}
                <div className="text-center mb-4">
                  <span className="text-text-placeholder" style={{ fontSize: 'var(--text-small)' }}>
                    Sarah Chen from Customer Support has joined the chat
                  </span>
                </div>

                {/* Sarah's Message */}
                <div className="mb-2">
                  <div className="ml-14 flex flex-col gap-3">
                    {/* Message bubble */}
                    <div className="bg-surface-light px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopLeftRadius: 'var(--radius-bubble-tail)', maxWidth: '280px' }}>
                      <p className="text-foreground" style={{ fontSize: 'var(--text-body)' }}>
                        Hi Maya, I'm Sarah Chen and I can see your conversation with Aria. I'm looking into this now and will be right with you.
                      </p>
                    </div>
                  </div>

                  {/* Avatar and Timestamp */}
                  <div className="flex gap-3 items-center mt-2">
                    <div className="rounded-full w-10 h-10 flex-shrink-0 flex items-center justify-center text-white" style={{ fontSize: '14px', fontWeight: 'var(--font-weight-semibold)', backgroundColor: '#06b6d4' }}>
                      S
                    </div>
                    <span className="text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>Sarah Chen · 03:01 PM</span>
                  </div>
                </div>
              </>
            )}

            {/* Person Handoff Flow */}
            {showPersonHandoff && (
              <>
                {/* User Message - Talk to a person now */}
                <div className="flex justify-end mb-4">
                  <div className="flex flex-col items-end">
                    <div className="bg-primary text-white px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopRightRadius: 'var(--radius-bubble-tail)', maxWidth: '240px' }}>
                      <p style={{ fontSize: 'var(--text-body)' }}>Talk to a person now</p>
                    </div>
                    <span className="mt-1 mr-2 text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>02:43 PM</span>
                  </div>
                </div>

                {/* AI Response - Connecting message */}
                <div className="mb-2">
                  <div className="ml-14 flex flex-col gap-3">
                    {/* Message bubble */}
                    <div className="bg-surface-light px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopLeftRadius: 'var(--radius-bubble-tail)', maxWidth: '280px' }}>
                      <p className="text-foreground" style={{ fontSize: 'var(--text-body)' }}>
                        I'm connecting you with Sarah Chen from our billing team now. She'll have all the details about your duplicate charge and can confirm the refund status. Estimated wait time is 3–5 minutes.
                      </p>
                    </div>
                  </div>

                  {/* Avatar and Timestamp */}
                  <div className="flex gap-3 items-center mt-2">
                    <div className="bg-primary rounded-full w-10 h-10 flex-shrink-0 flex items-center justify-center text-white" style={{ fontSize: '14px', fontWeight: 'var(--font-weight-semibold)' }}>
                      A
                    </div>
                    <span className="text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>02:43 PM</span>
                  </div>
                </div>

                {/* Warning Banner */}
                <div className="bg-warning-bg border px-4 py-3 mb-4 mx-4" style={{ borderColor: 'var(--warning-border)', borderRadius: 'var(--radius-card-sm)' }}>
                  <div className="flex items-start gap-2 mb-2">
                    <span style={{ fontSize: '16px' }}>⚠️</span>
                    <p className="text-warning-text" style={{ fontSize: 'var(--text-body)', fontWeight: 'var(--font-weight-semibold)' }}>
                      Connecting you to <span style={{ fontWeight: 'var(--font-weight-semibold)' }}>Sarah Chen</span>
                    </p>
                  </div>
                  <p className="text-warning-text mb-1" style={{ fontSize: 'var(--text-body)', fontWeight: 'var(--font-weight-semibold)' }}>
                    Estimated wait: <span style={{ fontWeight: 'var(--font-weight-semibold)' }}>3–5 minutes</span>
                  </p>
                  <p className="text-warning-text" style={{ fontSize: 'var(--text-small)' }}>
                    Your conversation history has been shared with the agent.
                  </p>
                </div>

                {/* Agent Joined Message */}
                <div className="text-center mb-4">
                  <span className="text-text-placeholder" style={{ fontSize: 'var(--text-small)' }}>
                    Sarah Chen from Customer Support has joined the chat
                  </span>
                </div>

                {/* Sarah's Message */}
                <div className="mb-2">
                  <div className="ml-14 flex flex-col gap-3">
                    {/* Message bubble */}
                    <div className="bg-surface-light px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopLeftRadius: 'var(--radius-bubble-tail)', maxWidth: '280px' }}>
                      <p className="text-foreground" style={{ fontSize: 'var(--text-body)' }}>
                        Hi Maya. I'm Sarah Chen and I can see your conversation with Aria. I'm looking into this now and will be right with you.
                      </p>
                    </div>
                  </div>

                  {/* Avatar and Timestamp */}
                  <div className="flex gap-3 items-center mt-2">
                    <div className="rounded-full w-10 h-10 flex-shrink-0 flex items-center justify-center text-white" style={{ fontSize: '14px', fontWeight: 'var(--font-weight-semibold)', backgroundColor: '#06b6d4' }}>
                      S
                    </div>
                    <span className="text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>Sarah Chen · 02:43 PM</span>
                  </div>
                </div>
              </>
            )}

            {!showEndConversation && showTrackOrder ? (
              <>
                {/* User Message - Track an order */}
                <div className="flex justify-end mb-4">
                  <div className="flex flex-col items-end">
                    <div className="bg-primary text-white px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopRightRadius: 'var(--radius-bubble-tail)', maxWidth: '200px' }}>
                      <p style={{ fontSize: 'var(--text-body)' }}>Track an order</p>
                    </div>
                    <span className="mt-1 mr-2 text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>02:10 PM</span>
                  </div>
                </div>

                {/* AI Response - Order Tracking Info */}
                <div className="mb-6">
                  <div className="ml-14 flex flex-col gap-3">
                    {/* Message bubble with order tracking details */}
                    <div className="bg-surface-light px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopLeftRadius: 'var(--radius-bubble-tail)', maxWidth: '280px' }}>
                      <p className="text-foreground mb-3" style={{ fontSize: 'var(--text-body)' }}>
                        You have 3 orders! Here's what's happening:
                      </p>

                      <div className="mb-3">
                        <p className="text-foreground" style={{ fontSize: 'var(--text-body)' }}>
                          <span style={{ fontWeight: 'var(--font-weight-semibold)' }}>Wireless Headphones</span> (ORD-4471) — Out for delivery today! Tracking: 274899234501
                        </p>
                      </div>

                      <div className="mb-3">
                        <p className="text-foreground" style={{ fontSize: 'var(--text-body)' }}>
                          <span style={{ fontWeight: 'var(--font-weight-semibold)' }}>Phone Case — Midnight Black</span> (ORD-4392) — Delivered April 25
                        </p>
                      </div>

                      <div>
                        <p className="text-foreground" style={{ fontSize: 'var(--text-body)' }}>
                          <span style={{ fontWeight: 'var(--font-weight-semibold)' }}>Mechanical Keyboard — Compact</span> (ORD-4180) — Returned (refund completed)
                        </p>
                      </div>
                    </div>

                    {/* Track order options */}
                    {!showTrackingDetails && (
                      <div className="flex flex-col gap-2" style={{ maxWidth: '260px' }}>
                        {/* First button - full width */}
                        <button
                          onClick={trackOrderOptions[0].action}
                          className="bg-background border text-primary hover:bg-primary-lighter transition-all px-3 py-2 text-center"
                          style={{
                            borderColor: 'var(--border)',
                            borderRadius: 'var(--radius-chip)',
                            fontSize: 'var(--text-button)',
                            fontWeight: 'var(--font-weight-medium)',
                            borderWidth: '1px'
                          }}
                        >
                          {trackOrderOptions[0].label}
                        </button>

                        {/* Second row - 2 buttons */}
                        <div className="grid grid-cols-2 gap-2">
                          {trackOrderOptions.slice(1, 3).map((option, index) => (
                            <button
                              key={index}
                              className="bg-background border text-primary hover:bg-primary-lighter transition-all px-3 py-2 text-center"
                              style={{
                                borderColor: 'var(--border)',
                                borderRadius: 'var(--radius-chip)',
                                fontSize: 'var(--text-button)',
                                fontWeight: 'var(--font-weight-medium)',
                                borderWidth: '1px'
                              }}
                            >
                              {option.label}
                            </button>
                          ))}
                        </div>

                        {/* Third button - full width */}
                        <button
                          onClick={trackOrderOptions[3].action}
                          className="bg-background border text-primary hover:bg-primary-lighter transition-all px-3 py-2 text-center"
                          style={{
                            borderColor: 'var(--border)',
                            borderRadius: 'var(--radius-chip)',
                            fontSize: 'var(--text-button)',
                            fontWeight: 'var(--font-weight-medium)',
                            borderWidth: '1px'
                          }}
                        >
                          {trackOrderOptions[3].label}
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {showTrackingDetails ? (
                  <>
                    {/* User Message - Track Wireless Headphones with FedEx */}
                    <div className="flex justify-end mb-4">
                      <div className="flex flex-col items-end">
                        <div className="bg-primary text-white px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopRightRadius: 'var(--radius-bubble-tail)', maxWidth: '240px' }}>
                          <p style={{ fontSize: 'var(--text-body)' }}>Track Wireless Headphones with FedEx</p>
                        </div>
                        <span className="mt-1 mr-2 text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>02:15 PM</span>
                      </div>
                    </div>

                    {/* AI Response - Tracking Details */}
                    <div className="mb-2">
                      <div className="ml-14 flex flex-col gap-3">
                        {/* Message bubble with tracking link */}
                        <div className="bg-surface-light px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopLeftRadius: 'var(--radius-bubble-tail)', maxWidth: '280px' }}>
                          <p className="text-foreground mb-3" style={{ fontSize: 'var(--text-body)' }}>
                            Your <span style={{ fontWeight: 'var(--font-weight-semibold)' }}>Wireless Headphones</span> are out for delivery today with FedEx and should arrive by May 2nd.
                          </p>
                          <p className="text-foreground mb-1" style={{ fontSize: 'var(--text-body)' }}>
                            Track it directly:
                          </p>
                          <p className="text-primary" style={{ fontSize: 'var(--text-body)' }}>
                            https://fedex.com/track?num=274899234501 (tracking #274899234501)
                          </p>
                        </div>

                        {/* Tracking details options */}
                        <div className="flex flex-col gap-2" style={{ maxWidth: '260px' }}>
                          {trackingDetailsOptions.map((option, index) => (
                            <button
                              key={index}
                              onClick={option.action}
                              className="bg-background border text-primary hover:bg-primary-lighter transition-all px-3 py-2 text-center"
                              style={{
                                borderColor: 'var(--border)',
                                borderRadius: 'var(--radius-chip)',
                                fontSize: 'var(--text-button)',
                                fontWeight: 'var(--font-weight-medium)',
                                borderWidth: '1px'
                              }}
                            >
                              {option.label}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Avatar and Timestamp at bottom */}
                    <div className="flex gap-3 items-center">
                      <div className="bg-primary rounded-full w-10 h-10 flex-shrink-0 flex items-center justify-center text-white" style={{ fontSize: '14px', fontWeight: 'var(--font-weight-semibold)' }}>
                        A
                      </div>
                      <span className="text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>02:15 PM</span>
                    </div>
                  </>
                ) : (
                  <>
                    {/* Avatar and Timestamp at bottom */}
                    <div className="flex gap-3 items-center">
                      <div className="bg-primary rounded-full w-10 h-10 flex-shrink-0 flex items-center justify-center text-white" style={{ fontSize: '14px', fontWeight: 'var(--font-weight-semibold)' }}>
                        A
                      </div>
                      <span className="text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>02:10 PM</span>
                    </div>
                  </>
                )}
              </>
            ) : !showEndConversation && !showReturnFlow ? null : (
              <>
                {/* User Message - Return an item */}
                <div className="flex justify-end mb-4">
                  <div className="flex flex-col items-end">
                    <div className="bg-primary text-white px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopRightRadius: 'var(--radius-bubble-tail)', maxWidth: '200px' }}>
                      <p style={{ fontSize: 'var(--text-body)' }}>Return an item</p>
                    </div>
                    <span className="mt-1 mr-2 text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>09:38 AM</span>
                  </div>
                </div>

                {/* AI Response with order info */}
                <div className="mb-6">
                  <div className="ml-14 flex flex-col gap-3">
                    {/* Message bubble with order details */}
                    <div className="bg-surface-light px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopLeftRadius: 'var(--radius-bubble-tail)', maxWidth: '260px' }}>
                      <p className="text-foreground mb-2" style={{ fontSize: 'var(--text-body)' }}>
                        I can help with that. You have one delivered order available for return:
                      </p>
                      <p className="text-foreground mb-1" style={{ fontSize: 'var(--text-body)', fontWeight: 'var(--font-weight-semibold)' }}>
                        Phone Case – Midnight Black
                      </p>
                      <p className="text-foreground mb-2" style={{ fontSize: 'var(--text-body)' }}>
                        (delivered April 25)
                      </p>
                      <p className="text-foreground" style={{ fontSize: 'var(--text-body)' }}>
                        Would you like to return this item?
                      </p>
                    </div>

                    {/* Return options - 1 on top, 2 on bottom */}
                    {!showReturnReason && (
                      <div className="flex flex-col gap-2" style={{ maxWidth: '260px' }}>
                        {/* Top option */}
                        {returnOptionsTop.map((option, index) => (
                          <button
                            key={index}
                            onClick={option.action}
                            className="bg-background border text-primary hover:bg-primary-lighter transition-all px-3 py-2 text-center"
                            style={{
                              borderColor: 'var(--border)',
                              borderRadius: 'var(--radius-chip)',
                              fontSize: 'var(--text-button)',
                              fontWeight: 'var(--font-weight-medium)',
                              borderWidth: '1px'
                            }}
                          >
                            {option.label}
                          </button>
                        ))}

                        {/* Bottom row - 2 options */}
                        <div className="grid grid-cols-2 gap-2">
                          {returnOptionsBottom.map((option, index) => (
                            <button
                              key={index}
                              className="bg-background border text-primary hover:bg-primary-lighter transition-all px-3 py-2 text-center"
                              style={{
                                borderColor: 'var(--border)',
                                borderRadius: 'var(--radius-chip)',
                                fontSize: 'var(--text-button)',
                                fontWeight: 'var(--font-weight-medium)',
                                borderWidth: '1px'
                              }}
                            >
                              {option.label}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {showReturnReason ? (
                  <>
                    {/* User Message - Yes, return the phone case */}
                    <div className="flex justify-end mb-4">
                      <div className="flex flex-col items-end">
                        <div className="bg-primary text-white px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopRightRadius: 'var(--radius-bubble-tail)', maxWidth: '240px' }}>
                          <p style={{ fontSize: 'var(--text-body)' }}>Yes, return the phone case</p>
                        </div>
                        <span className="mt-1 mr-2 text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>09:44 AM</span>
                      </div>
                    </div>

                    {/* AI Response - Asking for reason */}
                    <div className="mb-6">
                      <div className="ml-14 flex flex-col gap-3">
                        {/* Message bubble */}
                        <div className="bg-surface-light px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopLeftRadius: 'var(--radius-bubble-tail)', maxWidth: '260px' }}>
                          <p className="text-foreground" style={{ fontSize: 'var(--text-body)' }}>
                            Got it. Can you let me know why you'd like to return it?
                          </p>
                        </div>

                        {/* Return reason options with varying grid layout */}
                        {!showReturnSummary && (
                          <div className="flex flex-col gap-2" style={{ maxWidth: '260px' }}>
                            {returnReasonOptions.map((row, rowIndex) => (
                              <div key={rowIndex} className={`grid gap-2`} style={{ gridTemplateColumns: row.length === 2 ? '1fr 1fr' : '1fr' }}>
                                {row.map((option, index) => (
                                  <button
                                    key={index}
                                    onClick={option.action}
                                    className="bg-background border text-primary hover:bg-primary-lighter transition-all px-3 py-2 text-center"
                                    style={{
                                      borderColor: 'var(--border)',
                                      borderRadius: 'var(--radius-chip)',
                                      fontSize: 'var(--text-button)',
                                      fontWeight: 'var(--font-weight-medium)',
                                      borderWidth: '1px'
                                    }}
                                  >
                                    {option.label}
                                  </button>
                                ))}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>

                    {showReturnSummary ? (
                      <>
                        {/* User Message - Damaged or defective */}
                        <div className="flex justify-end mb-4">
                          <div className="flex flex-col items-end">
                            <div className="bg-primary text-white px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopRightRadius: 'var(--radius-bubble-tail)', maxWidth: '240px' }}>
                              <p style={{ fontSize: 'var(--text-body)' }}>Damaged or defective</p>
                            </div>
                            <span className="mt-1 mr-2 text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>09:45 AM</span>
                          </div>
                        </div>

                        {/* AI Response - Return Summary */}
                        <div className="mb-6">
                          <div className="ml-14 flex flex-col gap-3">
                            {/* Message bubble with return summary */}
                            <div className="bg-surface-light px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopLeftRadius: 'var(--radius-bubble-tail)', maxWidth: '280px' }}>
                              <p className="text-foreground mb-3" style={{ fontSize: 'var(--text-body)' }}>
                                Let me confirm the details with you:
                              </p>
                              <p className="text-foreground mb-2" style={{ fontSize: 'var(--text-body)', fontWeight: 'var(--font-weight-semibold)' }}>
                                Return Summary:
                              </p>
                              <div className="text-foreground mb-3" style={{ fontSize: 'var(--text-body)' }}>
                                <p className="mb-1">- Item: Phone Case – Midnight Black (ORD-4392)</p>
                                <p className="mb-1">- Refund: $27.05 to your Visa ending 4242</p>
                                <p className="mb-1">- Return label: FedEx (email + download in app)</p>
                                <p className="mb-1">- Drop off within 14 days of receiving the label</p>
                                <p>- Refund processes 3–5 business days after we receive the item</p>
                              </div>
                              <p className="text-foreground" style={{ fontSize: 'var(--text-body)' }}>
                                Ready to proceed?
                              </p>
                            </div>

                            {/* Confirm options - 2 buttons side by side */}
                            {!showReturnConfirmed && (
                              <div className="grid grid-cols-2 gap-2" style={{ maxWidth: '260px' }}>
                                {confirmOptions.map((option, index) => (
                                  <button
                                    key={index}
                                    onClick={option.action}
                                    className="bg-background border text-primary hover:bg-primary-lighter transition-all px-3 py-2 text-center"
                                    style={{
                                      borderColor: 'var(--border)',
                                      borderRadius: 'var(--radius-chip)',
                                      fontSize: 'var(--text-button)',
                                      fontWeight: 'var(--font-weight-medium)',
                                      borderWidth: '1px'
                                    }}
                                  >
                                    {option.label}
                                  </button>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>

                        {showReturnConfirmed ? (
                          <>
                            {/* User Message - Confirm return */}
                            <div className="flex justify-end mb-4">
                              <div className="flex flex-col items-end">
                                <div className="bg-primary text-white px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopRightRadius: 'var(--radius-bubble-tail)', maxWidth: '200px' }}>
                                  <p style={{ fontSize: 'var(--text-body)' }}>Confirm return</p>
                                </div>
                                <span className="mt-1 mr-2 text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>09:55 AM</span>
                              </div>
                            </div>

                            {/* AI Response - Return Confirmed */}
                            <div className="mb-2">
                              <div className="ml-14 flex flex-col gap-3">
                                {/* Message bubble with confirmation */}
                                <div className="bg-surface-light px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopLeftRadius: 'var(--radius-bubble-tail)', maxWidth: '280px' }}>
                                  <p className="text-foreground mb-2" style={{ fontSize: 'var(--text-body)' }}>
                                    All set! Your return has been initiated.
                                  </p>
                                  <p className="text-foreground mb-2" style={{ fontSize: 'var(--text-body)' }}>
                                    <span style={{ fontWeight: 'var(--font-weight-semibold)' }}>Return ID:</span> R-439221
                                  </p>
                                  <p className="text-foreground" style={{ fontSize: 'var(--text-body)' }}>
                                    Your FedEx return label has been emailed to you and is also available in the app. Drop it off at any FedEx location within 14 days. You'll get your $27.05 refund 3–5 business days after we receive it.
                                  </p>
                                </div>

                                {/* Final options - full width buttons */}
                                {!showEndConversation && (
                                  <div className="flex flex-col gap-2" style={{ maxWidth: '260px' }}>
                                    {finalOptions.map((option, index) => (
                                      <button
                                        key={index}
                                        onClick={option.action}
                                        className="bg-background border text-primary hover:bg-primary-lighter transition-all px-3 py-2 text-center"
                                        style={{
                                          borderColor: 'var(--border)',
                                          borderRadius: 'var(--radius-chip)',
                                          fontSize: 'var(--text-button)',
                                          fontWeight: 'var(--font-weight-medium)',
                                          borderWidth: '1px'
                                        }}
                                      >
                                        {option.label}
                                      </button>
                                    ))}
                                  </div>
                                )}
                              </div>
                            </div>

                            {!showEndConversation && (
                              <>
                                {/* Avatar and Timestamp at bottom */}
                                <div className="flex gap-3 items-center">
                                  <div className="bg-primary rounded-full w-10 h-10 flex-shrink-0 flex items-center justify-center text-white" style={{ fontSize: '14px', fontWeight: 'var(--font-weight-semibold)' }}>
                                    A
                                  </div>
                                  <span className="text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>09:51 AM</span>
                                </div>
                              </>
                            )}
                          </>
                        ) : (
                          <>
                            {/* Avatar and Timestamp at bottom */}
                            <div className="flex gap-3 items-center">
                              <div className="bg-primary rounded-full w-10 h-10 flex-shrink-0 flex items-center justify-center text-white" style={{ fontSize: '14px', fontWeight: 'var(--font-weight-semibold)' }}>
                                A
                              </div>
                              <span className="text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>09:45 AM</span>
                            </div>
                          </>
                        )}
                      </>
                    ) : (
                      <>
                        {/* Avatar and Timestamp at bottom */}
                        <div className="flex gap-3 items-center">
                          <div className="bg-primary rounded-full w-10 h-10 flex-shrink-0 flex items-center justify-center text-white" style={{ fontSize: '14px', fontWeight: 'var(--font-weight-semibold)' }}>
                            A
                          </div>
                          <span className="text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>09:44 AM</span>
                        </div>
                      </>
                    )}
                  </>
                ) : (
                  <>
                    {/* Avatar and Timestamp at bottom */}
                    <div className="flex gap-3 items-center">
                      <div className="bg-primary rounded-full w-10 h-10 flex-shrink-0 flex items-center justify-center text-white" style={{ fontSize: '14px', fontWeight: 'var(--font-weight-semibold)' }}>
                        A
                      </div>
                      <span className="text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>09:38 AM</span>
                    </div>
                  </>
                )}
              </>
            )}

            {/* Talk to Real Person Flow */}
            {showTalkToRealPerson && (
              <>
                {/* User Message - I want to talk to a real person */}
                <div className="flex justify-end mb-4">
                  <div className="flex flex-col items-end">
                    <div className="bg-primary text-white px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopRightRadius: 'var(--radius-bubble-tail)', maxWidth: '240px' }}>
                      <p style={{ fontSize: 'var(--text-body)' }}>I want to talk to a real person</p>
                    </div>
                    <span className="mt-1 mr-2 text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>03:19 PM</span>
                  </div>
                </div>

                {/* AI Response - Ask what they need help with */}
                <div className="mb-2">
                  <div className="ml-14 flex flex-col gap-3">
                    {/* Message bubble */}
                    <div className="bg-surface-light px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopLeftRadius: 'var(--radius-bubble-tail)', maxWidth: '280px' }}>
                      <p className="text-foreground" style={{ fontSize: 'var(--text-body)' }}>
                        I can connect you with someone right now. Can you tell me briefly what you need help with so I can make sure you reach the right person?
                      </p>
                    </div>
                  </div>

                  {/* Avatar and Timestamp */}
                  <div className="flex gap-3 items-center mt-2">
                    <div className="bg-primary rounded-full w-10 h-10 flex-shrink-0 flex items-center justify-center text-white" style={{ fontSize: '14px', fontWeight: 'var(--font-weight-semibold)' }}>
                      A
                    </div>
                    <span className="text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>03:19 PM</span>
                  </div>
                </div>
              </>
            )}

            {/* End Conversation Survey - Shared across all flows */}
            {showEndConversation && (
              <>
                {/* User Message - End conversation */}
                <div className="flex justify-end mb-4">
                  <div className="flex flex-col items-end">
                    <div className="bg-primary text-white px-3 py-2" style={{ borderRadius: 'var(--radius-bubble)', borderTopRightRadius: 'var(--radius-bubble-tail)', maxWidth: '200px' }}>
                      <p style={{ fontSize: 'var(--text-body)' }}>End conversation</p>
                    </div>
                    <span className="mt-1 mr-2 text-text-placeholder" style={{ fontSize: 'var(--text-timestamp)' }}>
                      {showTrackOrder ? '02:15 PM' : '09:51 AM'}
                    </span>
                  </div>
                </div>

                {/* Chat ended message */}
                <div className="text-center mb-6">
                  <span className="text-text-placeholder" style={{ fontSize: 'var(--text-small)' }}>
                    Chat ended - {showTrackOrder ? '02:15 PM' : '09:51 AM'}
                  </span>
                </div>

                {/* Feedback Survey Card */}
                {!feedbackSubmitted ? (
                  <div className="bg-background border rounded-xl px-4 py-4 mx-4 mb-4" style={{ borderColor: 'var(--border)', borderRadius: 'var(--radius-card)' }}>
                    <h3 className="text-foreground mb-1" style={{ fontSize: 'var(--text-header)', fontWeight: 'var(--font-weight-semibold)' }}>
                      How did we do today?
                    </h3>
                    <p className="text-text-medium mb-4" style={{ fontSize: 'var(--text-small)' }}>
                      Your feedback helps us improve.
                    </p>

                    {/* Overall satisfaction */}
                    <p className="text-foreground mb-2" style={{ fontSize: 'var(--text-body)', fontWeight: 'var(--font-weight-medium)' }}>
                      Overall satisfaction
                    </p>
                    <div className="flex justify-between mb-4">
                      {satisfactionEmojis.map((emoji, index) => (
                        <button
                          key={index}
                          onClick={() => setSelectedSatisfaction(index)}
                          className="w-12 h-12 rounded-full flex items-center justify-center transition-all hover:bg-surface-light"
                          style={{
                            fontSize: '24px',
                            filter: selectedSatisfaction !== null && index <= selectedSatisfaction ? 'none' : 'grayscale(100%)',
                            opacity: selectedSatisfaction !== null && index <= selectedSatisfaction ? 1 : 0.4
                          }}
                        >
                          {emoji}
                        </button>
                      ))}
                    </div>

                    {/* Was your issue resolved */}
                    <p className="text-foreground mb-2" style={{ fontSize: 'var(--text-body)', fontWeight: 'var(--font-weight-medium)' }}>
                      Was your issue resolved?
                    </p>
                    <div className="grid grid-cols-3 gap-2 mb-4">
                      {[
                        { label: "✓ Yes", value: "yes" },
                        { label: "~ Partially", value: "partially" },
                        { label: "✗ No", value: "no" }
                      ].map((option) => (
                        <button
                          key={option.value}
                          onClick={() => setSelectedResolved(option.value)}
                          className={`border px-3 py-2 transition-all ${
                            selectedResolved === option.value
                              ? 'border-primary'
                              : 'border-border hover:bg-surface-lighter'
                          }`}
                          style={{
                            borderRadius: 'var(--radius-button)',
                            fontSize: 'var(--text-button)',
                            fontWeight: 'var(--font-weight-medium)',
                            borderWidth: '1.5px',
                            backgroundColor: selectedResolved === option.value ? 'var(--primary-light)' : 'var(--background)',
                            color: selectedResolved === option.value ? 'var(--primary)' : 'var(--foreground)',
                            whiteSpace: 'nowrap'
                          }}
                        >
                          {option.label}
                        </button>
                      ))}
                    </div>

                    {/* Optional feedback text */}
                    <p className="text-foreground mb-2" style={{ fontSize: 'var(--text-body)', fontWeight: 'var(--font-weight-medium)' }}>
                      Anything else to share? <span className="text-text-placeholder">(optional)</span>
                    </p>
                    <textarea
                      placeholder="Tell us what we could do better..."
                      className="w-full px-3 py-3 bg-surface-lighter border-0 mb-4 resize-none focus:outline-none focus:ring-1 focus:ring-primary-border"
                      rows={3}
                      style={{
                        borderRadius: 'var(--radius-button)',
                        fontSize: 'var(--text-body)',
                        color: 'var(--foreground)'
                      }}
                    />

                    {/* Submit button */}
                    <button
                      onClick={() => setFeedbackSubmitted(true)}
                      disabled={selectedSatisfaction === null || selectedResolved === null}
                      className="w-full px-4 py-3 transition-colors"
                      style={{
                        borderRadius: 'var(--radius-button)',
                        fontSize: 'var(--text-button)',
                        fontWeight: 'var(--font-weight-medium)',
                        backgroundColor: selectedSatisfaction !== null && selectedResolved !== null ? 'var(--primary)' : 'var(--primary-lighter)',
                        color: selectedSatisfaction !== null && selectedResolved !== null ? 'white' : 'var(--primary)',
                        cursor: selectedSatisfaction !== null && selectedResolved !== null ? 'pointer' : 'not-allowed',
                        opacity: selectedSatisfaction !== null && selectedResolved !== null ? 1 : 0.7
                      }}
                    >
                      Submit feedback
                    </button>
                  </div>
                ) : (
                  <div className="bg-background border rounded-xl px-4 py-4 mx-4 mb-4" style={{ borderColor: 'var(--border)', borderRadius: 'var(--radius-card)' }}>
                    <div className="text-center">
                      <div className="mb-3" style={{ fontSize: '48px' }}>👋</div>
                      <p className="text-foreground" style={{ fontSize: 'var(--text-body)' }}>
                        Thanks for your feedback, Maya! It helps us improve every day.
                      </p>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>

          {/* Text Input */}
          <div className="px-4 py-3 bg-background border-t" style={{ borderColor: 'var(--divider)' }}>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && inputMessage.trim()) {
                    const message = inputMessage.trim();
                    setCustomMessages([...customMessages, message]);
                    if (message.toLowerCase().includes("charged twice")) {
                      setShowBillingResponse(true);
                    } else if (message.toLowerCase().includes("help with order")) {
                      setShowHelpWithOrder(true);
                    } else if (message.toLowerCase().includes("missing accessories")) {
                      setShowMissingAccessories(true);
                    } else if (message.toLowerCase().includes("change the name on my account")) {
                      setShowAccountTransfer(true);
                    } else if (message.toLowerCase().includes("third time") && message.toLowerCase().includes("canceling")) {
                      setShowEscalation(true);
                    }
                    setInputMessage("");
                  }
                }}
                placeholder="Type a message..."
                className="flex-1 px-4 py-3 bg-surface-lighter text-foreground border-0 focus:outline-none focus:ring-1 focus:ring-primary-border"
                style={{
                  borderRadius: 'var(--radius-input)',
                  fontSize: 'var(--text-body)'
                }}
              />
              <button className="text-text-medium hover:text-foreground p-2">
                <Paperclip className="w-5 h-5" />
              </button>
              <button
                onClick={() => {
                  if (inputMessage.trim()) {
                    const message = inputMessage.trim();
                    setCustomMessages([...customMessages, message]);
                    if (message.toLowerCase().includes("charged twice")) {
                      setShowBillingResponse(true);
                    } else if (message.toLowerCase().includes("help with order")) {
                      setShowHelpWithOrder(true);
                    } else if (message.toLowerCase().includes("missing accessories")) {
                      setShowMissingAccessories(true);
                    } else if (message.toLowerCase().includes("change the name on my account")) {
                      setShowAccountTransfer(true);
                    } else if (message.toLowerCase().includes("third time") && message.toLowerCase().includes("canceling")) {
                      setShowEscalation(true);
                    }
                    setInputMessage("");
                  }
                }}
                className="bg-primary text-white rounded-full p-3 hover:bg-primary-hover transition-colors"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="flex-1 overflow-y-auto pb-20 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
      {/* Header */}
      <header className="bg-primary text-white px-4 py-4 sticky top-0 z-50">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-7 h-7" />
            <h1 style={{ fontSize: 'var(--text-header)', fontWeight: 'var(--font-weight-semibold)' }}>ShopFlow</h1>
          </div>

          {/* Chat Button */}
          <button
            onClick={() => setIsChatOpen(true)}
            className="bg-primary-lighter text-primary rounded-full p-3 hover:bg-primary-light transition-colors shadow-lg"
          >
            <MessageCircle className="w-6 h-6" />
          </button>
        </div>
      </header>

      <main className="px-4 py-6 bg-page-background">
        {/* Categories */}
        <section className="mb-8">
          <h2 className="text-foreground mb-4" style={{ fontSize: 'var(--text-header)', fontWeight: 'var(--font-weight-semibold)' }}>Categories</h2>
          <div className="grid grid-cols-4 gap-3">
            {categories.map((category) => (
              <button
                key={category.name}
                className="bg-background shadow-sm hover:shadow-md transition-shadow flex flex-col items-center gap-2 p-4"
                style={{ borderRadius: 'var(--radius-card-sm)' }}
              >
                <span className="text-3xl">{category.icon}</span>
                <span className="text-text-medium" style={{ fontSize: 'var(--text-small)' }}>{category.name}</span>
              </button>
            ))}
          </div>
        </section>

        {/* Banner */}
        <section className="mb-8">
          <div className="bg-gradient-to-r from-primary to-primary-hover p-6 text-white" style={{ borderRadius: 'var(--radius-bubble)' }}>
            <h3 className="mb-2" style={{ fontSize: 'var(--text-body)', fontWeight: 'var(--font-weight-medium)' }}>Summer Sale</h3>
            <p className="mb-3 opacity-90" style={{ fontSize: 'var(--text-button)' }}>Up to 50% off on selected items</p>
            <button className="bg-primary-lighter text-primary px-6 py-2 hover:bg-primary-light transition-colors" style={{ borderRadius: 'var(--radius-button)' }}>
              Shop Now
            </button>
          </div>
        </section>

        {/* Featured Products */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-foreground" style={{ fontSize: 'var(--text-header)', fontWeight: 'var(--font-weight-semibold)' }}>Featured Products</h2>
            <button className="text-primary" style={{ fontSize: 'var(--text-button)' }}>See All</button>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {featuredProducts.map((product) => (
              <div key={product.id} className="bg-background overflow-hidden shadow-sm" style={{ borderRadius: 'var(--radius-card-sm)' }}>
                <div className="relative aspect-square bg-surface-light">
                  <ImageWithFallback
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                  <button className="absolute top-2 right-2 bg-background rounded-full p-2 shadow-md">
                    <Heart className="w-4 h-4 text-text-medium" />
                  </button>
                </div>
                <div className="p-3">
                  <h4 className="text-foreground mb-1 line-clamp-1" style={{ fontSize: 'var(--text-button)' }}>{product.name}</h4>
                  <div className="flex items-center gap-1 mb-2">
                    <Star className="w-3 h-3 fill-primary text-primary" />
                    <span className="text-text-medium" style={{ fontSize: 'var(--text-small)' }}>{product.rating}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-primary" style={{ fontSize: 'var(--text-button)', fontWeight: 'var(--font-weight-semibold)' }}>{product.price}</span>
                    <button className="bg-primary text-white px-3 py-1 hover:bg-primary-hover transition-colors" style={{ borderRadius: 'var(--radius-button-sm)', fontSize: 'var(--text-small)' }}>
                      Add
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>

      </div>

      {/* Bottom Navigation */}
      <nav className="flex-shrink-0 bg-background border-t px-4 py-3" style={{ borderColor: 'var(--border)' }}>
        <div className="flex items-center justify-around">
          <button className="flex flex-col items-center gap-1 text-primary">
            <Home className="w-6 h-6" />
            <span style={{ fontSize: 'var(--text-small)' }}>Home</span>
          </button>
          <button className="flex flex-col items-center gap-1 text-text-medium">
            <Package className="w-6 h-6" />
            <span style={{ fontSize: 'var(--text-small)' }}>Orders</span>
          </button>
          <button className="flex flex-col items-center gap-1 text-text-medium">
            <Heart className="w-6 h-6" />
            <span style={{ fontSize: 'var(--text-small)' }}>Wishlist</span>
          </button>
          <button className="flex flex-col items-center gap-1 text-text-medium">
            <User className="w-6 h-6" />
            <span style={{ fontSize: 'var(--text-small)' }}>Profile</span>
          </button>
        </div>
      </nav>
    </div>
  );
}
