
  # eCommerce Mobile App Home Screen

  This is a code bundle for eCommerce Mobile App Home Screen. The original project is available at https://www.figma.com/design/buP2oVgeytJLpm0fAey3kc/eCommerce-Mobile-App-Home-Screen.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  